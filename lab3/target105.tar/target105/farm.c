/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_201()
{
    return 2438473397U;
}

unsigned getval_438()
{
    return 1479233688U;
}

void setval_416(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_455(unsigned x)
{
    return x + 4022571080U;
}

unsigned addval_422(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_474()
{
    return 2428996936U;
}

void setval_489(unsigned *p)
{
    *p = 3351742792U;
}

void setval_357(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_251(unsigned x)
{
    return x + 3536110217U;
}

unsigned getval_280()
{
    return 3372798345U;
}

void setval_130(unsigned *p)
{
    *p = 3286272329U;
}

unsigned getval_143()
{
    return 3286272456U;
}

unsigned addval_120(unsigned x)
{
    return x + 2463009215U;
}

unsigned addval_372(unsigned x)
{
    return x + 2463205674U;
}

void setval_403(unsigned *p)
{
    *p = 3374894729U;
}

unsigned getval_122()
{
    return 2948842121U;
}

unsigned getval_114()
{
    return 3677933225U;
}

void setval_401(unsigned *p)
{
    *p = 3281310089U;
}

void setval_236(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_316(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_409(unsigned x)
{
    return x + 3674787465U;
}

void setval_368(unsigned *p)
{
    *p = 3286272329U;
}

void setval_393(unsigned *p)
{
    *p = 3223372417U;
}

unsigned addval_439(unsigned x)
{
    return x + 3353381192U;
}

void setval_173(unsigned *p)
{
    *p = 3374370441U;
}

unsigned getval_288()
{
    return 2446231879U;
}

unsigned addval_481(unsigned x)
{
    return x + 3286272328U;
}

void setval_152(unsigned *p)
{
    *p = 3281309321U;
}

unsigned addval_360(unsigned x)
{
    return x + 3380920971U;
}

unsigned addval_359(unsigned x)
{
    return x + 3351415042U;
}

unsigned getval_157()
{
    return 3223900553U;
}

void setval_448(unsigned *p)
{
    *p = 3674784397U;
}

void setval_436(unsigned *p)
{
    *p = 3375940233U;
}

unsigned getval_281()
{
    return 2429659504U;
}

void setval_443(unsigned *p)
{
    *p = 2425475465U;
}

unsigned addval_278(unsigned x)
{
    return x + 3223375489U;
}

unsigned addval_282(unsigned x)
{
    return x + 3531915945U;
}

unsigned getval_190()
{
    return 2430642504U;
}

void setval_396(unsigned *p)
{
    *p = 3281047817U;
}

unsigned getval_171()
{
    return 3281047945U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
